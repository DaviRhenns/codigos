const quadrados = document.querySelector(".layout")

const linhas = 7
const colunas = 6
let colunaDoBloco = 3
let linhaDoBloco = 0

let tela = [[0,0,0,0,0,0],
            [0,0,0,0,0,0],
            [0,0,0,0,0,0],
            [0,0,0,0,0,0],
            [0,0,0,0,0,0],
            [0,0,0,0,0,0],
            [0,0,0,0,0,0]
]
          

function criarTela(){
    for (let l = 0; l < linhas; l++) {
        for (let c = 0; c < colunas; c++){
            if(tela[l][c] == 0){
                const novaDiv = document.createElement('div');
                novaDiv.classList.add('quadrado'); 
                quadrados.appendChild(novaDiv);
            }else{
                const novaDiv = document.createElement('div');
                novaDiv.classList.add('quadradoAtivo'); 
                quadrados.appendChild(novaDiv);
            }
        }
    }
}


function mostrarNaTela(){
    quadrados.querySelectorAll("div").forEach(element => {
        element.remove()
    });
    criarTela();
}

criarTela();

tela[linhaDoBloco][colunaDoBloco] = 1

mostrarNaTela();
console.log(tela);


window.addEventListener('keydown', (event) => {
    switch (event.key){
        case 'ArrowLeft':
            if(colunaDoBloco > 0 &&  tela[linhaDoBloco][colunaDoBloco-1] != 1){
                tela[linhaDoBloco][colunaDoBloco] = 0
                colunaDoBloco--
                tela[linhaDoBloco][colunaDoBloco] = 1
                mostrarNaTela();
            }
            break;
        
        case 'ArrowRight':
            if(colunaDoBloco < colunas-1 && tela[linhaDoBloco][colunaDoBloco+1] != 1){
                tela[linhaDoBloco][colunaDoBloco] = 0
                colunaDoBloco++
                tela[linhaDoBloco][colunaDoBloco] = 1
                mostrarNaTela(); 
            }
            break;  
    }
});

setInterval(() => {

    if(linhaDoBloco < linhas-1 && tela[linhaDoBloco+1][colunaDoBloco] != 1){
        tela[linhaDoBloco][colunaDoBloco] = 0
        linhaDoBloco++
        tela[linhaDoBloco][colunaDoBloco] = 1
        mostrarNaTela();
    }else{
        linhaDoBloco = 0
        tela[linhaDoBloco][colunaDoBloco] = 1
        mostrarNaTela();
    }

    if(!(linhaDoBloco < linhas-1 && tela[linhaDoBloco+1][colunaDoBloco] != 1)){
    }

}, 1000);

/*
for(let l = 0; l < linhas; l++){
        for(let c = 0; c < colunas; c++){
            
        }
    }

hdk.children.forEach(element => {
    element.remove()
});
*/