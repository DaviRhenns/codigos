const bts = document.querySelectorAll("button")
const input = document.querySelector("input")

bts.forEach(function(bt){
    bt.onclick = function(){
        if(bt.textContent == "C"){
            input.value = ""

        }else if(bt.textContent == "="){
            input.value = eval(input.value)

        }else{
            input.value += bt.textContent
        }
    }
})