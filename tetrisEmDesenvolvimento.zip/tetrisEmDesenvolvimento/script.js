const quadrados = document.querySelector(".layout")
const divDerrota = document.querySelector(".derrota")

const linhas = 7
const colunas = 6
let colunaDoBloco = 3
let linhaDoBloco = 0

let tela = [[0,0,0,0,0,0],
            [0,0,0,0,0,0],
            [0,0,0,0,0,0],
            [0,0,0,0,0,0],
            [0,0,0,0,0,0],
            [0,0,0,0,0,0],
            [0,0,0,0,0,0]
]

function mudarDisplay(){
    divDerrota.style.display = "none";
}

function criarTela(){
    for (let l = 0; l < linhas; l++) {
        for (let c = 0; c < colunas; c++){
            if(tela[l][c] == 0){
                const novaDiv = document.createElement('div');
                novaDiv.classList.add('quadrado'); 
                quadrados.appendChild(novaDiv);
            }else{
                const novaDiv = document.createElement('div');
                novaDiv.classList.add('quadradoAtivo'); 
                quadrados.appendChild(novaDiv);
            }
        }
    }
}


function mostrarNaTela(){
    quadrados.querySelectorAll("div").forEach(element => {
        element.remove()
    });
    criarTela();
}

function verificarLinha() {
    for (let l = linhas - 1; l >= 0; l--) {
        let completa = true;

        for (let c = 0; c < colunas; c++) {
            if (tela[l][c] == 0) {
                completa = false;
                break;
            }
        }

        if (completa) {
            // Faz todas as linhas acima descerem
            for (let y = l; y > 0; y--) {
                for (let x = 0; x < colunas; x++) {
                    tela[y][x] = tela[y - 1][x];
                }
            }

            // faz a linha vazia no final
            for (let x = 0; x < colunas; x++) {
                tela[0][x] = 0;
            }
            l++;
        }
    }
}

criarTela();

tela[linhaDoBloco][colunaDoBloco] = 1

mostrarNaTela();
console.log(tela);


window.addEventListener('keydown', (event) => {
    switch (event.key){
        case 'ArrowLeft':
            if(colunaDoBloco > 0 &&  tela[linhaDoBloco][colunaDoBloco-1] != 1){
                tela[linhaDoBloco][colunaDoBloco] = 0
                colunaDoBloco--
                tela[linhaDoBloco][colunaDoBloco] = 1
                mostrarNaTela();
            }
            break;
        
        case 'ArrowRight':
            if(colunaDoBloco < colunas-1 && tela[linhaDoBloco][colunaDoBloco+1] != 1){
                tela[linhaDoBloco][colunaDoBloco] = 0
                colunaDoBloco++
                tela[linhaDoBloco][colunaDoBloco] = 1
                mostrarNaTela(); 
            }
            break;  
    }
});

setInterval(() => {
    let blocoPassando = false
    for (let i = 0; i < colunas; i++) {
        if (tela[1][i] == 1 && linhaDoBloco != 1) {
            blocoPassando = true
        }
    }

    if (blocoPassando) {
        divDerrota.style.display = "grid";
        for (let l = 0; l < linhas; l++) {
            for (let c = 0; c < colunas; c++) {
                tela[l][c] = 0
                linhaDoBloco = 0
            }
            
        }
    }

    if(linhaDoBloco < linhas-1 && tela[linhaDoBloco+1][colunaDoBloco] != 1){
        tela[linhaDoBloco][colunaDoBloco] = 0
        if(!blocoPassando){
            linhaDoBloco++;
        }
        tela[linhaDoBloco][colunaDoBloco] = 1
        mostrarNaTela()
        verificarLinha()
    }else{
        linhaDoBloco = 0
        tela[linhaDoBloco][colunaDoBloco] = 1
        mostrarNaTela()
        verificarLinha()
    }

    
}, 500);

/*
for(let l = 0; l < linhas; l++){
        for(let c = 0; c < colunas; c++){
            
        }
    }

hdk.children.forEach(element => {
    element.remove()
});
*/