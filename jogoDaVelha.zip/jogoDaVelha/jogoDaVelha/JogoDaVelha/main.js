const bt = document.querySelectorAll("div.buttons button")
const pVitX = document.querySelector(".vitx")
const pVitO = document.querySelector(".vito")
const btFecharPopUp = document.querySelector(".vitoria .fechar")
const btReiniciar = document.querySelector(".vitoriasXO .Reiniciar")
const popUp = document.querySelector("div.vitoria")
const popUpP = document.querySelector("div.vitoria p")

const ox = ['O', 'X']
let turn = 0
let contX = 0
let contO = 0
let vitx = 0
let vito = 0
const jogadas = [
    [],
    [],
    [],
]

const vitoria = [
    [
        ["Z", "Z", "Z"],
        [" ", " ", " "],
        [" ", " ", " "],
    ],

    [
        [" ", " ", " "],
        ["Z", "Z", "Z"],
        [" ", " ", " "],
    ],

    [
        [" ", " ", " "],
        [" ", " ", " "],
        ["Z", "Z", "Z"],
    ],

    [
        [" ", " ", "Z"],
        [" ", "Z", " "],
        ["Z", " ", " "],
    ],

    [
        ["Z", " ", " "],
        [" ", "Z", " "],
        [" ", " ", "Z"],
    ],

    [
        ["Z", " ", " "],
        ["Z", " ", " "],
        ["Z", " ", " "],
    ],

    [
        [" ", "Z", " "],
        [" ", "Z", " "],
        [" ", "Z", " "],
    ],

    [
        [" ", " ", "Z"],
        [" ", " ", "Z"],
        [" ", " ", "Z"],
    ],
]

function ClickButton(bt, index) {
    bt.onclick = function() {
        if(bt.textContent.trim() != '') { return }

        bt.textContent = ox[turn % 2]
        console.log(jogadas)
        turn++

        const col = index % 3
        let lin = 0

        if(index <= 2) {
            lin = 0
        }
        else if(index <= 5) {
            lin = 1
        }
        else {
            lin = 2
        }

        jogadas[lin][col] = bt.textContent

        TesteVitoria()
    }
}

function TesteVitoria() {
    for(i = 0; i < 3; i++) {
        for(j=0;j<3;j++) {
            if(jogadas[i][j] == "X") {
                jogadas[i][j] = "Z"
            }
        }
    }
    
    contX = 0
    for(i = 0; i < 8; i++) {
       for(j = 0; j < 3; j ++) {
            for(x = 0; x < 3; x ++) {
                if(vitoria[i][j][x] == jogadas[j][x]) {
                    contX++
                    console.log("X: " + contX)
                    if(contX == 3) {
                        vitx++
                        pVitX.textContent =  "vitorias X: "+ vitx
                        popUpP.textContent = "Parabens, o X venceu!"
                        popUp.style.display = "flex"
                    }

                    
                }
            }
       }
       contX = 0;
    }

    for(i = 0; i < 3; i++) {
        for(j=0;j<3;j++) {
            if(jogadas[i][j] == "Z") {
                jogadas[i][j] = "X"
            }
        }
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    for(i = 0; i < 3; i++) {
        for(j=0;j<3;j++) {
            if(jogadas[i][j] == "O") {
                jogadas[i][j] = "Z"
            }
        }
    }
    
    contO = 0
    for(i = 0; i < 8; i++) {
       for(j = 0; j < 3; j ++) {
            for(x = 0; x < 3; x ++) {
                if(vitoria[i][j][x] == jogadas[j][x]) {
                    contO++
                    if(contO == 3) {
                        vito++
                        pVitO.textContent =  "vitorias O: "+ vito
                        popUpP.textContent = "Parabens, o O venceu!"
                        popUp.style.display = "flex"
                    }
                }
            }
       }
       contO = 0
    }

    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
            if(jogadas[i][j] == "Z") {
                jogadas[i][j] = "O"
            }
        }
    }

   
}

function limparTudo() {
    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
            jogadas[i][j] = ''
        }
    }
    bt.forEach(function(i){
        i.textContent = ''
    })
}

bt.forEach(ClickButton)

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

btFecharPopUp.onclick = function(){
    popUp.style.display = "none"
    limparTudo()
}

btReiniciar.onclick = function(){
    limparTudo()
}