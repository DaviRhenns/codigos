quadrados = document.querySelector(".layout")

layout = [["o","o"],
          ["o","o"]]


for (let i = 1; i <= 42; i++) {
    const novaDiv = document.createElement('div');
    novaDiv.classList.add('quadrado'); 
    quadrados.appendChild(novaDiv);
}

